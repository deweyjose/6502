  "trailing garbage in operand",WARNING,
  "] expected for indirect addressing mode",ERROR,
  "missing valid index register",ERROR,
  "pc-relative offset out of range: %ld",ERROR,
  "constant offset out of range: %ld",ERROR,
  "bad auto decrement/increment value: %d",ERROR,                     /* 05 */
  "indirect addressing not allowed",ERROR,
  "auto increment/decrement not allowed",ERROR,
  "short branch out of range: %ld",ERROR,
  "long branch out of range: %ld",ERROR,
  "decrement branch out of range: %ld",ERROR,                         /* 10 */
  "data size %d not supported",ERROR,
  "data expression doesn't fit into %d bits",ERROR,
  "illegal bit number specification: %d",ERROR,
  "omitted offset taken as 5-bit zero offset",WARNING,
  "immediate expression doesn't fit into %d bits",ERROR,              /* 15 */
  "directive ignored as selected CPU has no DP register",WARNING,
  "double size modifier ignored",WARNING,
  "addressing mode not supported",ERROR,
